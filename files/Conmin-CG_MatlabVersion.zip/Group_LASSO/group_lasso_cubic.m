function [z, history] = group_lasso_cubic(A, b, lambda, p, rho, alpha)
%  group_lasso  Solve group lasso problem via ADMM
%
% [x, history] = group_lasso(A, b, p, lambda, rho, alpha);
%
% solves the following problem via ADMM:
%
%   minimize 1/2*|| Ax - b ||_2^2 + \lambda sum(norm(x_i))
%
% The input p is a K-element vector giving the block sizes n_i, so that x_i
% is in R^{n_i}.
%
% The solution is returned in the vector x.
%
% history is a structure that contains the objective value, the primal and
% dual residual norms, and the tolerances for the primal and dual residual
% norms at each iteration.
%
% rho is the augmented Lagrangian parameter.
%
% alpha is the over-relaxation parameter (typical values for alpha are
% between 1.0 and 1.8).
%
%
% More information can be found in the paper linked at:
% http://www.stanford.edu/~boyd/papers/distr_opt_stat_learning_admm.html
%

t_start = tic;
% Global constants and defaults
QUIET    = 0;
MAX_ITER = 1000;
ABSTOL   = 1e-4;
RELTOL   = 1e-2;
gamma    = 1.0;

% Data preprocessing
[m, n] = size(A);

% save a matrix-vector multiply
Atb = A'*b;
% check that sum(p) = total number of elements in x
if (sum(p) ~= n)
    error('invalid partition');
end

% cumulative partition
cum_part = cumsum(p);
% CG solver
% x = zeros(n,1);
x = 0.1*ones(n,1);
%f = objective(A, b, lambda, x);
f = 0.0;
% c = grad(A, b, lambda, x, n, 1.0);
c = grad(A, b, lambda, x, cum_part);

if ~QUIET
    % fprintf('%3s\t%10s\t%10s\t%10s\t%10s\t%10s\n', 'iter', ...
    %  'r norm', 'eps pri', 's norm', 'eps dual', 'objective');
end

pertcnt = 0;    
nrst = n;
restart = false;

inPowell = false;
dprat = 0.0;
ddprat = 0.0;
lam = 0;

k = 0;

while (k < MAX_ITER)
    
        k = k + 1;

		xTx = dot(x,x); 
		cTc = dot(c,c);

		% Check for convergence
		if ( sqrt(cTc) <= sqrt(n)*ABSTOL + RELTOL*sqrt(xTx) ) % inftol*inftol*max(1.0, xTx) )
			status = 0;
			break;
        end

		% Compute step direction
		if ( restart == false )
            % fprintf("%4d :\t%14.6e\t %14.6e\t | %d \n", k, f, sqrt(cTc/max(1.0, xTx)), pertcnt);
			dx = -c;
        else
			% Test to see if the Powell restart criterion holds
			if ( abs(dot(c,c0)/cTc) > 0.2 && restart > 1 && nrst ~= n )
                inPowell = true;
                % fprintf("Here for this\n");
                if ( lam == 0.0 )
                    if ( dprat0 ~= 0.0 ) 
                        ddprat = ( abs(dot(c,c0)/cTc) - 2*prat + prat0 ) / ( (lam - olambda)*(oolambda-olambda) );
                    end
                    dprat0 = dprat;
                    if ( lam > 0 ) 
                        dprat = ( abs(dot(c,c0)/cTc) - prat ) / ( lam - olambda );
                    end
                    if (exist('prat','var'))
                        prat0 = prat;
                    end
                    prat = abs(dot(c,c0)/cTc);
                    alpha = alpha0;
                    restart = restart0;
                    x = x0;
                    dx = dx0;
                    c0 = c00;
%                     c = grad(A, b, lambda, x, n, 1.0);
                    c = grad(A, b, lambda, x, cum_part);
                    xTx = dot(x,x);
                    cTc = dot(c,c);
                    if (exist('olambda','var'))
                        oolambda = olambda;
                    end
                    olambda = lam;
                    if ( lam == 0.0 )
                        lam = prat/0.2; 
                    else
                        if ( pertcnt <= 2 )
                            lam = olambda - prat/dprat;
                        else
                            if ( dprat*dprat - 2*ddprat*prat > 0 && abs(ddprat) > 1e-8 )
                                lam = olambda + max( (-dprat + sqrt(dprat*dprat - 2*ddprat*prat))/ddprat, ...
                                            (-dprat - sqrt(dprat*dprat - 2*ddprat*prat))/ddprat ); 
                            else
                                lam = 2*olambda;
                            end
                        end
                        if ( lam < 1e-12 ) 
                            lam = 2*olambda;
                        end
                    end
                else
                    lam = 2*lam;
                end
                pertcnt = pertcnt + 1;
                k = k - 1;
            else
				dx0 = dx;
				lam = 0.0;
				dprat = 0.0;
				dprat0 = 0.0;
				prat0 = 0.0;
				% fprintf("%4d :\t%14.6e\t %14.6e\t | %d \n", k, f, sqrt(cTc/max(1.0, xTx)), pertcnt);
				pertcnt = 0;
            end

			% If performing a restart, update the Beale restart vectors
			if ( nrst == n )
                pt = alpha*dx;
                yt = c - c0;
                ytTyt = dot(yt,yt);
                cTyt = dot(pt,yt);
                cTct = dot(pt,pt);
            end
            
			p = alpha*dx;
			y = c - c0;
            pTc = dot(pt,c);
			yTc = dot(yt,c);


			u1 = -dot(pt,c)/ytTyt;
			u2 = 2*dot(pt,c)/cTyt - dot(yt,c)/ytTyt;
			u3 = cTyt/ytTyt;
            
			bracket = lam*lam + 2*lam*ytTyt/cTyt + ytTyt/cTct;
			a = -cTyt/(lam*cTyt + ytTyt);
			b1 = (-lam*cTyt - 2*ytTyt)*ytTyt/(cTyt*cTct*bracket*(lam*cTyt + ytTyt));
			d = lam/(bracket*(lam*cTyt + ytTyt));
			e = ytTyt/(cTct*bracket*(lam*cTyt + ytTyt));

			bracket = lam*lam+lam/u3+lam*ytTyt/cTyt+cTyt/(u3*cTct);
			denom = u3*u3*cTct*lam*bracket + u3*cTct*bracket;
			d = u3*u3*lam*(cTct/cTyt) / denom;

			dx = a*c + b1*pTc*pt + d*yTc*yt + e*yTc*pt + e*pTc*yt;
			
            if ( nrst ~= n )
                % inv(H+lI)*y
				ptTy = dot(pt,y);
				ytTy = dot(yt,y);
				temp1 = -(a*y + b1*ptTy*pt + d*ytTy*yt + e*ytTy*pt + e*ptTy*yt);

				% inv(H+lI)*invH*p
				a2 = 1.0/(lam*u3+1.0);
				b2 = lam*b1;
				d2 = lam*d;
				e2 = lam*e;
				ptTp = dot(pt,p);
				ytTp = dot(yt,p);
				temp2 = a2*p + b2*ptTp*pt + d2*ytTp*yt + e2*ytTp*pt + e2*ptTp*yt;

				u10 = dot(temp1, c); % yT inv(H+lI) g
				u11 = dot(temp2, c); % pT invH inv(H+lI) g
				u12 = dot(temp1, y); % yT inv(H+lI) y
				u13 = dot(temp2, y); % pT invH inv(H+lI) y
				u14 = dot(temp2, p); % pT invH inv(H+lI) p
				u15 = dot(p, y);	 % pTy 

				denom = lam*u14*(u15 + u12) + u13*u13;
				
				% dx = -inv(H+lI)*g --- Remember the minus sign
				dx = dx + lambda*u14*u10*temp1/denom - ...
                        (u15 + u12)*u11*temp2/denom + ...
                        u13*u10*temp2/denom + u13*u11*temp1/denom;
            end
        end

		% Check that the search direction is a descent direction
		dxTc = dot(dx, c);
		if ( dxTc > 0 )
% fprintf("CUBIT: Search direction is not a descent direction.\n");
			status = 3;
			break;
        end

		% Save the current point
		f0 = f;
        x0 = x;
        if (exist('c0','var'))
            c00 = c0;
        end
        c0 = c;
        alpha0 = alpha;
		restart0 = restart;

		if ( restart == 0 )
			restart = 1;
        else
			if ( pertcnt == 0 )
				if ( nrst == n ) 
                    nrst = 0;
                end
				nrst = nrst + 1;
				restart = 2;
            end
        end


        
        Adx = A*dx;
        alpha0 = dot( (b - A*x), Adx )/dot( Adx, Adx );
        x1 = x + alpha0*dx;
        numer = sum( dx.*(x1 < -gamma) - lambda*x.*dx.*(-gamma < x1 < gamma) - ...
            dx.*(x1 > gamma) );
        denom = sum( lambda*dx.*dx.*( -gamma < x1 < gamma)  );
        alpha = ( dot( (b - A*x), Adx ) + numer ) / ( dot( Adx, Adx ) + denom );
        
        afind = @(a) objective(A, b, lambda, cum_part,  x + a*dx, x);
        alpha = fminbnd(afind, 0, 100);

        
        % Take the step and update function value and gradient
		x = x0 + alpha*dx;
%        f = objective(A, b, lambda, x);
%         c = grad(A, b, lambda, x, n, 1.0);
        c = grad(A, b, lambda, x, cum_part);


end

if ~QUIET
    toc(t_start);
end

    z = x;
    history = x;
    fprintf('n = %d, iters = %d, inCubic = %d\n', n, k, inPowell);
end

function p = objective(A, b, lambda, cum_part, x, z)
    obj = 0;
    start_ind = 1;
    for i = 1:length(cum_part)
        sel = start_ind:cum_part(i);
        obj = obj + norm(z(sel));
        start_ind = cum_part(i) + 1;
    end
    p = ( 1/2*sum((A*x - b).^2) + lambda*obj );
end


function c = grad(A, b, lambda, x, cum_part)
    start_ind = 1;
    c =A'*(A*x-b);
    for i = 1:length(cum_part)
        sel = start_ind:cum_part(i);
        c(sel) = c(sel) +lambda*x(sel)/(norm(x(sel)));

%          c(sel) = c(sel) +lambda*x(sel)/(norm(x(sel))+0.01);
        start_ind = cum_part(i) + 1;
    end
end
randn('seed', 0);
rand('seed',0);

m = 5000;       % number of examples
n = 200;       % number of features
p = 100/n;      % sparsity density

for rr = 1:100
    x0 = sprandn(n,1,p);
    A = randn(m,n);
    A = A*spdiags(1./sqrt(sum(A.^2))',0,n,n); % normalize columns
    b = A*x0 + sqrt(0.001)*randn(m,1);

    lambda_max = norm( A'*b, 'inf' );
    lambda = 0.001*lambda_max;

    % Solve problem

    [x history] = full_huber_cg(A, b, lambda, 1.0, 1.0);
end
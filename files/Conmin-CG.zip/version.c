char conmin_version[] = "Version 2.0 (20130918)";

char conmin_bsname[] = "CONMIN 2.0";
